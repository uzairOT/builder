import React from 'react'
import SideBar from '../../components/Settings/SideBar/SideBar'
import Layout3 from '../../components/Layouts/Layout3'

function Settings() {
    return (
        <div>
            <Layout3 />
        </div>
    )
}

export default Settings
