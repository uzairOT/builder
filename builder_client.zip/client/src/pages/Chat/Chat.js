import React from 'react'
import ChatUsersCard from '../../components/Chat/ChatUsersCard'

function Chat() {
  return (
    <div><ChatUsersCard /></div>
  )
}

export default Chat