const BottomCircle = {
    width: "1.1875rem",
    height: "1.1875rem",
    flexShrink: 0,
    borderRadius: "1.1875rem",
    background: "rgba(83, 83, 83, 0.35)",
    marginTop: "1.5rem",
  };
  export default BottomCircle;
  