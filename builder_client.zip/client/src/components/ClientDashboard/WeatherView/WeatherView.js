import React from 'react'

function WeatherView() {
    return (
        <div>

        </div>
    )
}

export default WeatherView
