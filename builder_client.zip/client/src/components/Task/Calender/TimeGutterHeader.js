import { Box, Typography } from '@mui/material'
import React from 'react'

const TimeGutterHeader = () => {
  return (
    <Box>
        <Typography color={"#6A6A6A"} fontFamily={"Montserrat, sans-serif"} textAlign={'center'}>Week</Typography>
    </Box>
  )
}

export default TimeGutterHeader
